﻿using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DTICustomerAPI.Models
{
    public class DataAccess
    {
        MongoClient _client;
        MongoServer _server;
        MongoDatabase _db;

        [Obsolete]
        public DataAccess()
        {
            _client = new MongoClient("mongodb://rpsaccount:o973t29OJg59HMHKrY9FPY5A64LaKxOql573t2IwMZD0TcTUAUSZMybe7ktgrSegKn2Kr6jWYTwNOMBdOObPVA==@rpsaccount.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@rpsaccount@");
            _server = _client.GetServer();
            _db = _server.GetDatabase("BankDB");

            
        }

        public IEnumerable<Customer> GetCustomers()
        {
            return _db.GetCollection<Customer>("Customers").FindAll();
        }


        public Customer GetCustomer(String id)
        {
            var res = Query<Customer>.EQ(p => p.Id, id);
            return _db.GetCollection<Customer>("Customers").FindOne(res);
        }

        public Customer  Create(Customer customer)
        {
            _db.GetCollection<Customer>("Customers").Save(customer);
            return customer;
        }

    }
}
