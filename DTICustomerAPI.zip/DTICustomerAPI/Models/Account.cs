﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DTICustomerAPI.Models
{
    

    public class Account
    {
        [BsonElement]
        public long AccountNo { get; set; }
        [BsonElement]
        public long Balance { get; set; }
        [BsonElement]
        public AccountType Account_Type { get; set; }

    }
}
