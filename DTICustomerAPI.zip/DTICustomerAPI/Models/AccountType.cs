﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DTICustomerAPI.Models
{
    public enum AccountType
    {
        SAVINGS,CURRENT,DEMAT
    }
}
