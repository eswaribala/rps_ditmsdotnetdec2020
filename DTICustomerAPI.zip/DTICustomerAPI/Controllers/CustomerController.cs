﻿using DTICustomerAPI.Models;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DTICustomerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        // GET: api/<CustomerController>
        private DataAccess _dataAccess;
        public CustomerController(DataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        // GET: api/Game
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return new ObjectResult(_dataAccess.GetCustomers());
        }
        // GET: api/Customer/id
        [HttpGet("{id}", Name = "Get")]
        public async Task<IActionResult> Get(String id)
        {
            var order = _dataAccess.GetCustomer(id);
            if (order == null)
                return new NotFoundResult();
            return new ObjectResult(order);
        }
        // POST: api/Order
        [HttpPost]
        public IActionResult Post([FromBody] Customer customer)
        {
            _dataAccess.Create(customer);
            return new OkObjectResult(customer);
        }
    }
}
